# International Space Station Tracking

## B1 Team 2

### Vishal Pandey - Team Lead, Research, Integration & Folium

### Durgasi Sireesha - Flask & HTML-CSS

### Amit Bukan - Python

### Charu Joshi - Requests
